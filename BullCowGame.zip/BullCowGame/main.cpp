#include<iostream>
#include<string>
#include "FBullCowGame.h"


using FText = std::string;
using int32 = int;

void printIntro();
void PlayGame();
FText GetGuess();
bool AskToAgain();

FBullCowGame BcGame;

int main()
{
	bool bplayagain = false;
	do
	{
		printIntro();
		PlayGame();
		AskToAgain();
	} while (bplayagain);

	return 0;
}

// Print The Into

void printIntro()
{
	constexpr int32 WORLD_LENGTH = 5;

	// Game Strartup Message 

	std::cout << " Hi Welcome to Bull & Cow game \n";
	std::cout << " Comeon Guess the " << WORLD_LENGTH << "  Letter isogram ,  i'm thinking of !" << std::endl;
	return;
}


void PlayGame()
{
	FBullCowGame BcGame;
	BcGame.Reset();
	int32 MyMaxTries = BcGame.GetMaxTry();
	// number of length of isogram

	for (int32 count = 1; count <= MyMaxTries; count++)
	{
		FText Guess = GetGuess();
		FBullCowCount  BullCowCount = BcGame.SubmitGuess(Guess);
		
		std::cout << " Bull = " << BullCowCount.Bull;
		std::cout << ". Cow = " << BullCowCount.Cow << std:: endl;
	}

}


FText GetGuess()
{
	// Player Guess
	FBullCowGame BcGame;

	int32 MyCurrentTry = BcGame.GetCurrentTry();

	std::cout << " Try " << MyCurrentTry << ". Enter Your Guess: ";
	FText  Guess = "";
	std::getline(std::cin, Guess);
	return Guess;
}

bool AskToAgain()
{
	std::cout << " Do You Want To Play Again (y/n) ? " << std::endl;
	FText Response = " ";
	std::getline(std::cin, Response);
	return (Response[0] = 'y') || (Response[0] = 'Y');
}