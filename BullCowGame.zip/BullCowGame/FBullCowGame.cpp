#include "FBullCowGame.h"

int32  FBullCowGame::GetCurrentTry() const { return MyCurrentTry; }
FBullCowGame::FBullCowGame() {Reset();}
int32  FBullCowGame::GetMaxTry() const { return MyMaxTries; }

void FBullCowGame::Reset()
{
	constexpr int32 MaxTries = 8;
	MyMaxTries = MaxTries;
	MyCurrentTry = 1;

	const FString HiddenWord = " plant";
	MyHiddenWord = HiddenWord;
	return;
}



bool  FBullCowGame::IsGameWon() const
{
	return false;
}

bool  FBullCowGame::CheckGuessValidity(FString)
{
	return false;
}

FBullCowCount FBullCowGame::SubmitGuess(FString Guess)
{
	MyCurrentTry++;

	FBullCowCount BullCowCount;
	int32 HiddenWordLength = MyHiddenWord.length();
	for (int32 i = 0; i < HiddenWordLength; i++)
	{
		for (int32 j = 0; j < HiddenWordLength; ++j)
		{
			if (Guess[i] == MyHiddenWord[i])
			{
				if (i == j)
				{
					BullCowCount.Bull++;
				}
				else
				{
					BullCowCount.Cow++;
				}
			}

		}
	}
	
	return BullCowCount;
}


